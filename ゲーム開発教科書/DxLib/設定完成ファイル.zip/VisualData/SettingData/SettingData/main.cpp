#include "DxLib.h"
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
    ChangeWindowMode(TRUE);	//ウィンドウモード変更
    DxLib_Init();			//Dxライブラリ初期化
    SetGraphMode(640, 480, 32);		//画面サイズ
    SetDrawScreen(DX_SCREEN_BACK);	//裏画面設定
    while (ProcessMessage() == 0) {
        ClearDrawScreen();	//画面初期化

        ScreenFlip();		//画面更新
    }
    DxLib_End();
    return 0;
}